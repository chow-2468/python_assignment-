import json,os
from Item_maintenance import clean

'''''    
dis_code = {'STUDENT':
            {'discount': 0.20,
             'status': 'SPECIFIC',
             'item_available':["IPAD0A","IPAD0P","IPAD0M",
                               "PEN002","MAC00P","MAC00A"]},
            'DISCNT10':
            {'discount': 0.10,  
            'status':'ALL'},
            'DISCNT15':
            {'discount': 0.15,
            'status':'ALL'}}
'''

def auto_del(discode,item_list):# AUTO DEL THE ITEM CODE WHICH NOT IN THE ITEM LIST
    for x in discode:
        if discode[x]['status'] == 'SPECIFIC':
            for y in discode[x]['item_available']:
                if y not in item_list.keys():
                    discode[x]['item_available'].remove(y)

def save(discode): # SAVE DATA  

    f_json = open(r'data/dis_code.txt','w+')
    f_json.write(json.dumps(discode,indent= 2))
    f_json.close

def new_dis(discode,item_list):# ADD NEW DISCOUNT CODE
    x = 1 # INITIATOR
    while x==1:
        code = input("create a discount code  (press Q to cancel):").upper().strip()
        
        if code in discode.keys(): # TO CHECK THE NEW CODE IS USED OR NOT
            print('the code has been used.') 

        elif code == 'Q':
            x = 0 # END THE LOOP
        else: 
            while x==1:
                discount = input('key in discount amount in decimal e.g. 0.20 (press Q to cancel): ').upper() 
                if discount == 'Q':
                        x = 0
                else:
                    try:
                        discount = float(discount)
                    except:
                        print('invalid')
                    else:
                        if discount >1 or discount < 0: #  THE DISCOUNT NEITHER MORE THAN 1 NOR NEGATIVE 
                            print ('invalid (no negetive)')
                        else:
                            while x == 1:
                                status = input('the discount is used to <A>ll item or <S>pecific item ? (press Q to cancel):').upper() 
                                # TO LET USER TO CHOOSE THE DISCOUNT TO ALL ITEM OR SPECIFIC ITEM ONLY
                                
                                if status in ['A','S','Q']:
                                    if status == 'A':
                                        discode.update({code :{'discount':discount,
                                                               'status': 'ALL' }}) 
                                    
                                    elif status == 'S':
                                        I_code_list = []
                                        
                                        while x==1: 
                                            item_code = input('key in the item code which can discount (press Q to stop):').upper().strip()
                                            if item_code in item_list:
                                                if item_code not in I_code_list:
                                                    I_code_list.append(item_code)
                                                    print((', ').join(I_code_list))
                                                
                                                else:
                                                    print('item already added')
                                            
                                            elif item_code == 'Q':
                                                x = 0
                                            
                                            else:
                                                print('invalid code')
                                        
                                        discode.update({code:{'discount':discount,
                                                              'status':'SPECIFIC',
                                                              'item_available':I_code_list}})
                                    
                                    x = 0
                                else:
                                    print ('invalid option')

def del_dis(discode): # DELETE DISCOUNT CODE
    x = 1 
    while x==1:
        code = input("Key in discount code  (press Q to cancel):").upper().strip()
        
        if code == 'Q': 
            x =0
        elif code not in discode.keys(): # TO ENSURE USER KEY IN CORRECT CODE
            print('Invalid discount code.') 
            
        else: 
            discode.pop(code)
            x=0


def change_status(discode,item_list): # CHANGE THE ITEM STATUS
    x=1
    while x==1:
        code=input('key in the discount code (press Q to cancel)').upper().strip()
        if code == 'Q': 
            
            x=0
        elif code not in discode:
            
            print(' invalid discount code')
        else:
            while x ==1:
                status = input('the discount is used to <A>ll item or <S>pecific item ? (press Q to cancel):').upper().strip()
                if status in ['A','S','Q']:
                    if status == 'A':
                        
                        if discode[code]['status'] != 'ALL':
                            discode[code]['status'] = 'ALL'
                            discode[code].pop('item_available')
                            x=0
                            
                        else:
                            print('The discount code\'s status already in ALL')

                    elif status == 'S':
                        I_code_list = []
                        if  discode[code]['status'] != 'SPECIFIC':
                            while x==1: 
                                item_code = input('key in the item code which can discount (press Q to stop):').upper().strip()
                                
                                if item_code in item_list:
                                    if item_code in I_code_list:
                                        print('this item already add')

                                    else:
                                        I_code_list.append(item_code)
                                        print(I_code_list)

                                elif item_code == 'Q':
                                    x = 0
                                else:
                                    print('invalid code')
                            discode[code]['status'] = 'SPECIFIC'
                            discode[code]['item_available'] = I_code_list
                            x=0
                            
                        else:
                            print('The discount code\'s status already in Specific')
                    else:
                        x=0   
                else:
                    print('invalid option')     
                                    
      # ITEM AVAILABLE LIST, ITEM LIST
def add_item(item_available,item_list): # ADD ITEM AVAILABLE
    x =1
    while x==1:
        item_code = input('key in the item code (press Q to cancel):').upper().strip()
        if item_code in item_list:
            if item_code in item_available:
                print('This item is added')
            else:
                item_available.append(item_code)
                x=0
                
                
        elif item_code == 'Q':
            x=0
        else:
            print('invalid code')
    
    return item_available

#DISCOUNT CODE, ITEM AVAILABLE LIST, DISCOUNT LIST
def del_item(code,item_available,discode):# DELETE ITEM 
    x =1
    while x==1:
        item_code = input('key in the item code (press Q to cancel):').upper().strip()
        if item_code in item_available:    

            item_available.remove(item_code)
            discode[code]['status']= 'SPECIFIC'
            x=0
            
        elif item_code == 'Q':
            x=0
        else:
            print('invalid code')
    return item_available

#CODE IN DISCOUNT LIST , ITEM AVAILABLE LIST, ITEM LIST
def item_ui(code,item_available,item_list): # PRINT ITEM UI
    print('-'*80,'\n{}'.format(code))
    print('-'*80)
    print('{:>3}    {:<15} {}'.format('NO.','Item Code','Item Name'))
    print('-'*80)

    i=0
    for x in item_available:# PRINT ALL THE ITEM AAND NAME
        i+=1
        print('{:>3}    {:<15} {}'.format(i,x,item_list[x]['name']))
    
    print('-'*80)
    print('<A>dd item       <D>eleted item        <Q>uit')
    print('-'*80)
    

def show_item(discode,item_list): # SHOW THE CODE ITEM AVAILABLE
    x=1
    while x==1:
        code = input('key in the discount code ( press Q to cancel) :').upper().strip()
        if code == 'Q':
            x=0
        
        elif code not in discode:
            print ('invalid code')
        else:
            if discode[code]['status'] == 'ALL':
                item_available= list(item_list)
            else:
                item_available= discode[code]['item_available']
            ui =1
            x=0
  
    while ui ==1:
        clean()
        item_ui(code,item_available,item_list)
        
        option = input('key in option: ').upper()
        if option not in ['A','D','Q']:
                print('invalid option')
        else:
            if option =='A':
                item_available = add_item(item_available,item_list)
                
            elif option == 'D':
                item_available = del_item(code,item_available,discode)
            else:
                ui =0
                if discode[code]['status']=='SPECIFIC':
                    discode[code]['item_available'] = item_available
                
                
                            
                                

def main_ui(discode): # PRINT THE DIS_MAIN UI
    i =0
    print('-'*80)
    print('DISCOUNT CODE MAINTENANCE')
    print('-'*80)
    print('{:>4}    {:<20}{:<25}{}'.format('No.','Code','Status','Discount') )
    print('-'*80)
    for x in discode:
        i+=1
        print('{:>4}    {:<20}{:<25}{:>8.2f}'.format(i,x,discode[x]['status'],discode[x]['discount'])) 
        #PRINT NO., DISCOUNT CODE, STATUS
    print('-'*80)
    print('<A>dd New Discound Code       <D>eleted Discount code\n\n'
          '<C>heck item available        Change Discount <S>tatus          <Q>uit')
    print('-'*80)

def dis_main(): 
    screen = 1
    

    with open(r'data/item_list.txt' , 'r+') as itemfile: # OPEN THE FILE AND READ THE FILE
        item_list = json.loads(itemfile.read()) #CONVERT THE JSON FILE(STRING) INTO DICT 

    with open(r'data/dis_code.txt', 'r+') as disfile: # OPEN THE FILE AND READ THE FILE
        dis_code = json.loads(disfile.read()) #CONVERT THE JSON FILE(STRING) INTO DICT 

    auto_del(dis_code,item_list)

    while screen ==1:
        
        main_ui(dis_code)

        screen = d_op(dis_code,item_list)
        clean()

def d_op(discode,item_list): # DECIDE WHICH FUNCTION WILL RUN
    
    screen =1
    x = 1
    while x==1:
        option = input('Option >>').upper().strip()
        if option not in ['C','S','Q','A','D']:
            print('invalid option')
        else:
            if option == 'Q':
                screen =0
                save(discode)

            elif option == 'S':
                change_status(discode,item_list)
            
            elif option == 'A':
                new_dis(discode,item_list)
            
            elif option == 'D':
                del_dis(discode)
            
                

            else:
                show_item(discode,item_list)
                
            x=0
    
    return screen

#dis_main()
