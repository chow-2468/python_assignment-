import json,os,datetime,Item_maintenance

def clean(): #clean the output
    os.system('cls' if os.name == 'nt' else 'clear')

def instock(item_list): #enter the item code and add the quantity the user want to add
   x=1

   while x==1:
      y=1
      while y==1: #loop until a valid item code or <Q>uit is enter
         code=str(input("Enter Item Code <Q>uit >>")).upper()
         if code=="Q":
            clean()
            y=0 #end nested while loop(while y==1)
            x=0#end nested while loop(while x==1)
            return "Q",0 #return code,quantity
         elif code in item_list.keys() :
            print ('Product:{}  Price:RM{}'.format(item_list[code]['name'],item_list[code]['price']))
            y=0
         else:#if the code!="Q" or any item code in item_list_keys
            print ('invalid code')
      if code in item_list: #add item quantity process will not function if the code not in item_list
         add_item=input("Enter quantity <B>ack <Q>uit >>").upper()
         try:
             add_item=int(add_item)
         except: #output when the quantity is string
            if add_item=="Q":
               clean()
               x=0 #end loop
               return "Q",0 #return code,quantity
            elif add_item=="B":
               y=1 #return to nested while loop(while y==1)
            else:
               print("invalid input")
         else: #output when the quantity is integer
            
            if 0>(item_list[code]['quantity'] + add_item):#loop back to enter the quantity as the quantity needed to add cannot less 0
               print('invalid')
            else:
               item_list[code]['quantity']+=add_item#successfully add item
               print('The current {} stock is {} unit(s)'.format(item_list[code]['name'],item_list[code]['quantity']))
               input('press enter to continue')
               return code, item_list[code]['quantity']#return code,quantity
               x=0
                   
def save_changes(information): #save the changes

    date= datetime.datetime.now().strftime('Date: %d-%m-%Y         Time: %H:%M:%S')# get current time
    i=0
    ui = '\n'+'-'*40+'\n{}\n'.format(date)+'-'*40 + '\n{:>3} {:<10}     {}\n'.format('NO.','Item code','Changes')+'-'*40+'\n\n'

    file=open(r'data/stock_history.txt','a+')# Open the file 'stock_history.txt' in append mode ('a+')
    file.write(ui)# Write the contents of the 'ui' variable to the file

    # Iterate over the 'information' list and write formatted data to the file
    for x in information:
        i+=1
        file.write('{:>2}  {:<10}     {:>5}     \n'.format(i,x[0],x[1]))

    file.write('-'*40+'\n')
    file.close()# Close the file after writing


def warning(item_list):#dispaly the item(s) which is(are) under the safety stock level
    print('-'*45)
    print('Warning list')
    print('-'*45)
    for item in item_list:#check every item in item_list
        if item_list[item]['quantity']<10:#if the item less than 10,then print the item name and quantity
            print ('{:<10}{:<25}{:>5}'.format(item,item_list[item]['name'],item_list[item]['quantity']))
    print('-'*45)

def stock_inventory_management():# Main function for the stock/inventory management system
    itemfile=open(r'data/item_list.txt','r+')#open the file and read the file
    item_list = json.loads(itemfile.read())#convert the json file(string) into dict
    itemfile.close()  # Close the file after reading its contents
    
    information = []#create a empty information list
    code = 0#initialization
    
    ui="-"*45+"\n"+"STOCK/INVENTORY MANAGEMENT"+"\n"+"-"*45+"\n"+datetime.datetime.now().strftime('Date: %d-%m-%Y         Time: %H:%M:%S')+"\n"+"-"*45
   
    while code != "Q":#repeat the program until the user want to <Q>uit
        print(ui)
        warning(item_list)
        code, quantity = instock(item_list)
        if code in item_list.keys():
            information.append([code, quantity])#append the code and quantity that are change into the information list
            print('-'*45)
            print("The safety stock level of all items is 10!")
            clean()
    
    #added part save changes and change item quantity
    if len(information) >0:
        save_changes(information)#save change 
        Item_maintenance.save_dict(item_list) # save changes in json file


   
#stock_inventory_management()

