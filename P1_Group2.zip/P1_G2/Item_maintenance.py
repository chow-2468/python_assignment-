import json , os

def clean(): #USED TO CLEAR THE SCREEN
    os.system('cls' if os.name == 'nt' else 'clear')


def add_n_item_list(item_lists): # USE TO ADD THE NEW ITEM IN THE ITEM LIST-

    x = 1 # INITIATOR
    while x==1:
        code = input("key in the code  (press Q to cancel):").upper().strip()
        
        if code in item_lists.keys(): # TO CHECK THE NEW CODE IS USED OR NOT
            print('the code has been used.') 

        elif code == 'Q':
            x = 0 #END THE LOOP
        else: 
            name = input ('key in the name of item (press Q to cancel): ').strip()
            if name.upper() == 'Q':
                x=0
            else:
                while x==1:
                    price = input('key in the price of item (press Q to cancel): ').upper()
                    try: # TO CHECK THE PRICE KEY IN IS A NUMBER AND ENSURE WHEN KEY IN ALPHABETS THE PROGRAM WILL NOT STOP
                        price= float(price)
                    except:
                        if price == 'Q':
                            x =0
                        else:
                            print('invalid')
                    else:
                        if price<0:
                            print ('the price cannot be negative.')
                        else:
                            while x==1:
                                quantity = input('key in the number of the quantity of item (press Q to cancel): ').upper()
                                try:
                                    quantity = int(quantity)
                                except:
                                    if quantity == 'Q':
                                        x = 0
                                    else:
                                        print('invalid')
                                else: # ADD ITEM AT THE END TO MAKESURE ALL IMFORMATION IS COLLECTED
                                    if quantity<0:
                                        print ('the price cannot be negative.')
                                    else:
                                        item_lists.update({code:{'name': name,
                                                                'price': price,
                                                                'quantity':quantity}})
                                        x=0

def save_dict(save): # SAVE THE DATA IN THE JSON FILE
    f_json = open(r'data/item_list.txt','w+')
    f_json.write(json.dumps(save,indent=2))
    f_json.close

def del_item(itemlist):# DELETE THE USED ITEM FROM THE ITEM LIST
    x = 1
    while x==1:
        code = input("key in the item code you want to del (press Q to cancel):").upper().strip()
        if code in itemlist.keys(): # MAKESURE THE CODE IS IN THE LIST
            x = 0
            itemlist.pop(code) 

        elif code == 'Q':
            x = 0
        else: 
            print ('invalid code') # REPEAT THE LOOP BECAUSE x = 1

def up_item_q(itemlist):  # UPDATE THE ITEM QUANTITY
    x =1
    while x == 1: 
        code = input("key in the item code you want to update (press Q to cancel):").upper().strip()

        if code in itemlist.keys(): # CHECK THE CODE IS IN THE ITEM LIST
            while x ==1 :
                quantity = input('key in the item quantity (press Q to cancel):').upper()
                
                if quantity == 'Q': # BREAK
                    x = 0
                    
                else:
                    
                    try: # USED TO CHECK IS NUMBER OR NOT
                        quantity =  int(quantity)
                    except:
                        print('invalid')       
                    else:
                        if quantity<0:
                            print ('the price cannot be negative.')
                        else:

                            itemlist[code]['quantity']=quantity
                            x=0
                    
        elif code == "Q":
            x = 0
        
        else: 
            print ('invalid code')

def up_item_p(itemlist): # UPDATE THE ITEM PRICE SAME CONCEPT WITH THE up_item_q()
    
    x =1
    while x == 1:
        code = input("key in the item code you want to update (press Q to cancel):").upper().strip()

        if code in itemlist.keys():
            while x ==1:
                price = input('key in the item price (press Q to cancel):').upper()

                if price == 'Q':
                    break
                    
                else:
                    
                    try:
                        price =  float(price)
                    except:
                        print('invalid')
                                
                    else:
                        if price<0:
                            print ('the price cannot be negative.')
                        else:

                            itemlist[code]['price']= price
                            x=0
                        
        elif code == "Q":
            x=0
        
        else: 
            print ('invalid code')

def I_main(): # MAIN OPTION LIST 
    with open(r'data/item_list.txt' , 'r+') as itemfile: # OPEN THE FILE AND READ THE FILE
        item_list = json.loads(itemfile.read()) #CONVERT THE JSON FILE(STRING) INTO DICT 

    screen = 1

    while screen == 1:
        print('-'*80)
        print ('Item Master Maintenance')
        print('-'*80)
        print('{:>4}    {:<20}{:<25}{:>8}{:>15}'.format('No.','Code','Item Name','Price','Stock') )
        print('-'*80)

        i = 0
        for y  in item_list: # LIST OUT ALL THE ITEM FROM THE LIST
            i+=1
            print('{:>4}    {:<20}{:<25}{:=10.2f}{:=11}'.format(i,y,item_list[y]['name'],item_list[y]['price'],item_list[y]['quantity']) )

        print('-'*80+'\n')

        print('{}    {:<20}{:<25}{:>15}'.format('New (N)','Modify (M)','Deleted (D)','Quit (Q)') )
        print('-'*80)
        screen =i_op(item_list) # TO DECIDE THE LOOP WILL CONTINUE OR NOT
        clean()

def i_op(item_list): # DECIDE WHICH FUNCTION WILL RUN
    a = 1
    screen = 1
    while a == 1:
        option = input('key in option >> ').upper().strip()

        if option in ['M','N','D','Q']:
            if option == 'M':
                while a==1 :

                    q_o_p = input('key in <S>tock or <P>rice (press Q to cancel): ').upper().strip()
                    # q_o_p means quantity or price

                    if q_o_p in ['Q','S','P']: 

                        if q_o_p =='S':
                            up_item_q(item_list)

                        elif q_o_p == 'P':
                            up_item_p(item_list)

                        a = 0
                        
                        
                    else:
                        print('invalid')

            elif option == 'N':

                add_n_item_list(item_list)
                
                
            elif option == 'D':
                del_item(item_list)
                

            else:
                while a==1:
                    save = input('Do you want to save the changes ? (Y/N):').upper().strip() # TO DECIDE SAVE OR NOT
                    if save in ['Y','N']:
                        if save =='Y':   
                            save_dict(item_list)
                        screen = 0
                        a=0
                        
                    else:
                        print('invalid')
            a= 0
            
                
        else:
            print('invalid option')
    
    return screen # USE TO DECIDE EITHER BREAK THE LOOP OR NOT IN I_main()

#I_main()
