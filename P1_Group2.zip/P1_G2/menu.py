import os
from Item_maintenance import *
from discount_code import *
from sales_but_better1 import*
from stock_inventory_management import*

def clean():
    os.system('cls' if os.name == 'nt' else 'clear')

def menu():
    global menu_quit
    menu_quit = 1
    while menu_quit:
        print("-"*80)
        print ("                            _____  _____  _      ______ ")
        print(r"                      /\   |  __ \|  __ \| |    |  ____|")
        print(r"                     /  \  | |__) | |__) | |    | |__   ")
        print(r"                    / /\ \ |  ___/|  ___/| |    |  __|  ")
        print(r"                   / ____ \| |    | |    | |____| |____ ")
        print(r"                  /_/    \_\_|    |_|    |______|______|")
        print("                                                                     Apple Store")
        print("-"*80)
        print("<1>Item Maintenance/Stock")
        print("<2>Discount")
        print("<3>Sales")
        print("<4>Inventory Management")
        print("<Q>uit")
        print("-"*80)
        choose = str(input("option>>").upper())

        #optionlist = ["1","2","3","4","5","Q"]
        #optionfuntion =[Item Maintenance/Stock,Discount,Sales,Inventory Management,Quit]
        
        option(["1","2","3","4","Q"],choose,[I_main,dis_main,sales_main,stock_inventory_management,Quit])
        
def option(optionlist,choose,optionfuntion="0"):
    if choose in optionlist:
        if optionfuntion !="0":
            clean()
            op = optionlist.index(choose)
            optionfuntion[op]()
    else:
        input("invalid input")
        clean()

def Quit():
    global menu_quit
    menu_quit = 0

menu()
