import time
import json
import os
from Item_maintenance import save_dict

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def label():
    print("-"*80)
    print("Sales Transaction Menu -->", "Time:",time.strftime("%H:%M:%S"), "Date:",time.strftime("%d-%m-%Y" )) 
    print("-"*80)

def code_data_validation():
    print("No record found")
    user_input=input("Enter item code(<P>ayment >>>").upper()
    return user_input

def quantity_validation():
    while True:
        try:
            Quantity=int(input("Enter quantity >>> "))
            
        except ValueError:
            print("Invalid quantity")
        else:
            return Quantity
            

def confirmation_validation(user_input):
    if user_input != "Y" and user_input != "N":
        print("Invalid option")




#add def
def find_code(item,item_list): #find item code
    namelist=[]
    for x in item_list:
        namelist.append(item_list[x]['name'])
    ilist = list(item_list) # item code list
    code = ilist[namelist.index(item)]
    return code

def dis(dis_code): #change discount code
    code = ''
    temp_dis= input('key in the discount code >>>').upper()
    if temp_dis in dis_code.keys():
        code = temp_dis
    else:
        print ('invalid discount code')
    
    return code

def count_discnt(code,items,items_price,discount,dis_code): #count discount
    dis=0

    if discount in dis_code:
        if dis_code[discount]['status']=='ALL':
            dis= items_price[items.index(code)]*dis_code[discount]['discount']
        else:
            if code in dis_code[discount]['item_available']:
                dis= items_price[items.index(code)]*dis_code[discount]['discount']
    return dis

def sales_main():
    items_bought=[]
    items_price=[]
    items_quan =[]
    discount= ''

    label()
    print("")

    n=0
    with open('data/item_list.txt' , 'r+') as f: 
        item_list = json.loads(f.read())
    with open('data/dis_code.txt' , 'r+') as disfile:
        dis_code = json.loads(disfile.read())
    
    x = 1
    while x ==1:
        dis_amount=0
        user_input=input("Enter item code(<P>ayment <D>iscount) >>>").upper()
            
        if user_input in item_list:

            Stock=item_list.get(user_input)["quantity"]
            Name=item_list.get(user_input)["name"]  
            Price=item_list.get(user_input)["price"] 

            
            print(Name,"(RM %.2f)"%(Price))
            print("")

            Quantity=quantity_validation()
            print("")
            
            proceed=input("Confirm and save? (Y/N) >>> ").upper()
            print("")
            confirmation_validation(proceed)

            Total=Price*Quantity

            

            if proceed=="Y":
                
                # changed part 
                if Name in items_bought:
                    Quantity+=items_quan[items_bought.index(Name)]
                    items_quan[items_bought.index(Name)] =Quantity    # UPDATED

                    Total=Price*items_quan[items_bought.index(Name)] # TO GET A MORE ACCURATE PRICE
                    items_price[items_bought.index(Name)] = Total    # UPDATE THE TOTAL PRICE
                else:
                    items_bought.append(Name)
                    items_quan.append(Quantity)
                    items_price.append(Total)    

                

                print("(",n+1,")",user_input)
                print("Item purchased: ",Name)
                print("Price: RM ",Price)
                print("Number of items: ",Quantity) 
                print("Total cost: RM ",Total,'\n')
                


                    
                n+=1
        elif user_input=="P":
            ori_price=price_sum=sum(items_price)
            clear_screen()
            label()
            for ele in items_bought:

                print(ele,end=" ")
                print("{0:<20}{1:^5}{2:>35}{3:>10.2f}".format(str(ele)+" (x"+str(items_quan[items_bought.index(ele)])+")",":","RM  ",items_price[items_bought.index(ele)]))
            # added part discount
            codelist=[]
            for item_name in items_bought:
                code=find_code(item_name,item_list)
                codelist.append(code)
            for j in codelist:
                dis_amount+=count_discnt(j,codelist,items_price,discount,dis_code)
                item_list[j]['quantity']-=items_quan[codelist.index(j)]
            
            print(" ")
            print("{0:<20}{1:^5}{2:>45}{3:>10.2f}".format("Before discnt",":","RM  ",ori_price))
            print("{0:<20}{1:^5}{2:>45}{3:>10.2f}".format("After discnt",":","RM -",dis_amount))
            print("{0:<20}{1:^5}{2:>45}{3:>10.2f}".format("Total price",":","RM  ",price_sum-dis_amount))
            print("-"*80)
            print("Thank you for your purchase")
            print("-"*80)
            Exit=input("Press any key to exit >>> ")
            
            #save
            global save_items_bought
            global save_items_quan
            global save_items_price
            global save_ori_price
            global save_price_sum
            global save_dis_amount
            save_items_bought=items_bought
            save_items_quan=items_quan
            save_items_price=items_price
            save_ori_price=ori_price
            save_dis_amount=dis_amount
            save_price_sum=price_sum
            save_transaction()
            
            clear_screen()
            label()
            items_bought.clear()
            items_price.clear()
            items_quan.clear()
            discount= None
            save_dict(item_list)
            n=0
            
        elif user_input=='D':
            discount = dis(dis_code)

        elif user_input=='Q':
            x=0
            clear_screen()
        
        

        else:
            print("No record found")



#save receipt
def save_transaction():
    with open("data/receipt.txt","a") as st:
        st.write("-"*80+"\n")
        st.write("Sales Transaction  -->"+"Time:"+str(time.strftime("%H:%M:%S"))+ "Date:"+str(time.strftime("%d-%m-%Y" ))+"\n")
        st.write("-"*80+"\n")
        for ele in save_items_bought:
            st.write("{0:<30}{1:^5}{2:>35}{3:>10.2f}".format(str(ele)+" (x"+str(save_items_quan[save_items_bought.index(ele)])+")",":","RM  ",save_items_price[save_items_bought.index(ele)])+"\n")
        st.write(" \n")
        st.write("{0:<30}{1:^5}{2:>35}{3:>10.2f}".format("Before discnt",":","RM  ",save_ori_price)+"\n")
        st.write("{0:<30}{1:^5}{2:>35}{3:>10.2f}".format("After discnt",":","RM -",save_dis_amount)+"\n")
        st.write("{0:<30}{1:^5}{2:>35}{3:>10.2f}".format("Total price",":","RM  ",save_price_sum-save_dis_amount)+"\n")
        st.write("-"*80+"\n")
        st.write(format("Thank you for your purchase","^80")+"\n")
        st.write("-"*80+"\n\n\n")
        

#sales_main()
